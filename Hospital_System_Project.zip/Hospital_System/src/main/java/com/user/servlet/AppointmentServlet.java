package com.user.servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AppointmentDao;
import com.db.DbConnect;
import com.entity.Appointment;

@WebServlet("/addAppointment")
public class AppointmentServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int userId = Integer.parseInt(req.getParameter("userid"));
		String fullname = req.getParameter("fullname");
		String gender = req.getParameter("gender");
		String ageStr = req.getParameter("age");
		String appointdateStr = req.getParameter("appointdate");
		String email = req.getParameter("email");
		String phno = req.getParameter("phno");
		String diseases = req.getParameter("diseases");
		int doctorid = Integer.parseInt(req.getParameter("doct"));
		String address = req.getParameter("address");

		HttpSession session = req.getSession();
		
		// Validate age
		int age;
		try {
			age = Integer.parseInt(ageStr);
			if (age > 100) {
				session.setAttribute("error", "Age cannot be greater than 100. Please enter a valid age.");
				resp.sendRedirect("user-appointment.jsp");
				return;
			}
		} catch (NumberFormatException e) {
			session.setAttribute("error", "Invalid age format. Please enter a valid age.");
			resp.sendRedirect("user-appointment.jsp");
			return;
		}
		
		// Validate appointment date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		try {
			LocalDate appointdate = LocalDate.parse(appointdateStr, formatter);
			LocalDate currentDate = LocalDate.now();
			LocalDate maxDate = currentDate.plusMonths(1);

			if (appointdate.isBefore(currentDate) || appointdate.isAfter(maxDate)) {
				session.setAttribute("error", "Appointment date must be within one month from today. Please select a valid date.");
				resp.sendRedirect("user-appointment.jsp");
				return;
			}
		} catch (DateTimeParseException e) {
			session.setAttribute("error", "Invalid date format. Please enter a valid appointment date.");
			resp.sendRedirect("user-appointment.jsp");
			return;
		}

		Appointment ap = new Appointment(userId, fullname, gender, ageStr, appointdateStr, email, phno, diseases, doctorid, address, "Pending");
		
		AppointmentDao dao = new AppointmentDao(DbConnect.getConn());
		
		if(dao.addAppointment(ap)) {
			session.setAttribute("sucMsg", "Appointment Added Successfully!");
			resp.sendRedirect("view-appointment.jsp");
		} else {
			session.setAttribute("error", "Something went wrong!");
			resp.sendRedirect("user-appointment.jsp");
		}
	}
}
