package com.user.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDao;
import com.db.DbConnect;

@WebServlet("/deleteUserAppoint")
public class DeleteUserAppoint extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		
		UserDao dao = new UserDao(DbConnect.getConn());
		HttpSession session = req.getSession();
		
		if(dao.deleteUserAppoint(id)) {
			session.setAttribute("sucMsg", "Appointment Deleted Sucessfully..");
			resp.sendRedirect("view-appointment.jsp");
		}else {
			session.setAttribute("error", "Something went wrong!");
			resp.sendRedirect("view-appointment.jsp");
		}
	}

}
