package com.doctor.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DoctorDao;
import com.dao.UserDao;
import com.db.DbConnect;

@WebServlet("/changeDoctorPass")
public class DoctorPaswordChange extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int uid= Integer.parseInt(req.getParameter("uid"));
		String oldPassword = req.getParameter("oldPassword");
		String newPassword = req.getParameter("newPassword");
		
		DoctorDao dao = new DoctorDao(DbConnect.getConn());
		HttpSession session = req.getSession();

		if(dao.checkOldPass(uid, oldPassword)) {
			
			if(dao.changePass(uid, newPassword)) {
				session.setAttribute("sucMsg", "Password Change Sucessfully");
				resp.sendRedirect("doctor/edit-profile.jsp");
		
			}else {
				session.setAttribute("error", "Something went wrong!");
				resp.sendRedirect("doctor/edit-profile.jsp");
			}
		}else {
			session.setAttribute("error", "Old password Incorrect");
			resp.sendRedirect("doctor/edit-profile.jsp");
	
		}

	}
}
